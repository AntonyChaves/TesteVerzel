Explicação da configuração e execução do código(Back-End)

Linguagem Utilizada: Java -> Escolhi esta linguagem pois é a linguagem que mais me identifico e tenho facilidade
em relação a desenvolvimento Back-End.

Framework utilizado: Spring -> Utilizei este framework pois considero ele como o mais completo para desenvolver
APIs em Java.

Utilizei vários funcionalidades Spring Validation, Spring Web e Lombok nesta aplicação.

Como banco de dados eu utilizei o MySQL, as configurações de conexão com o BD estão no arquivo application.properties
e para testá-lo, basta colocar a URL da conexão MySQL da máquina em questão e uma schema para ser usada para 
criar a tabela de Favoritos, é necessário também inserir username e password da conexão.

Toda a aplicação Back-End foi  feita em um padrão que tem como exemplo a arquitetura MVC, ou seja, eu possuo
packages que contém os arquivos separados por tipo:

 -> Package Entity abriga a classe Favoritos responsável por criar a tabela que irá conter os IDs dos filmes que
estão setados como favoritos no MySQL, utilizo annotations @Entity e @Table para definir a classe, que possui 
apenas o atributo ID, pois considerei que era o único atributo necessário para se guardar.

-> Package Repository contém a minha inteface Repository que extende a biblioteca JpaRepository, com ela, sou 
capaz de realizar operações com a tabela Favoritos como: save para cadastrar novos Favoritos, delete para remover
favoritos e findAll para recolher um Array com todos os favoritos cadastrados.

-> Package DTO contém a minha Record DTO que uso para ter certeza que todas as requsições feitas pelo Front
estejam corretas e sem faltar nenhum dado importante(no caso apenas o ID).

-> Package Controller contém a minha classe Controller responsável por receber todas as requisições HTTP feitas
pelo Front e encaminhar essas requisições para a classe Service que irá processá-las e retornar o valor adequado,
nos métodos dessa classe estão os Mappings para receber os tipos corretos de requisição(GET, POST, DELETE)

->Package Service é a classe mais importante da aplicação, pois é ela que verdadeiramente processa as operações
requisitadas pelo Front, nela está a injeção de dependência da classe Repository para fazer alterações nos 
registros do banco de dados e é nela que estão as chamadas HTTPRequest para a API do TMDB requisitando os dados
necessários, alguns método dela são:
                  º Métodos para adicionar e remover um favorito do banco de dados com repository.save(dado) e 
 repository.delete(dado) e métodos para verificar se o ID de um determinado filme está entre os registros do 
banco de dados;
                  º Métodos requisitando as dados de filmes da API do TMDB, esses dados são puxados através de
HTTP Connections que puxam os dados e armazenam em String Buffers, esses dados são então convertidos em JSON e 
retornados para uso do Front-End.

