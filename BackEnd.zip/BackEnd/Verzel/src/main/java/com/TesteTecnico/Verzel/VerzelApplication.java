package com.TesteTecnico.Verzel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerzelApplication {

	public static void main(String[] args) {
		SpringApplication.run(VerzelApplication.class, args);
	}

}
