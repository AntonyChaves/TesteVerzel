package com.TesteTecnico.Verzel.Service;

import com.TesteTecnico.Verzel.DTO.FavoritosDTO;
import com.TesteTecnico.Verzel.Entity.Favoritos;
import com.TesteTecnico.Verzel.Repository.FavoritosRepository;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@Service
public class ServiceRequest {


    public List todosFilmesPopulares() {

        try {
            URL url = new URL("https://api.themoviedb.org/3/movie/popular?language=pt-BR");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("accept", "application/json");
            con.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0YjFjYWYxNDNhMjA2ZmFjMWU0ZmFkNjIxZjJjY2NlZSIsIm5iZiI6MTcyNTQ1MTk3Mi42MjU4Miwic3ViIjoiNjZkODRkYjI0Yjc0MTRkNGIxMWFiNmZjIiwic2NvcGVzIjpbImFwaV9yZWFkIl0sInZlcnNpb24iOjF9._irTp0YQwrdzrXMH7DfkACI3uEQh6RfwexNgwaWSQU0");

            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line;
            StringBuilder resposta = new StringBuilder();

            while((line = bf.readLine()) != null){
                resposta.append(line);
            }

            bf.close();

            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(resposta.toString());

            List listaDeFilmes = (List) json.get("results");

            return listaDeFilmes;
        }
        catch(Exception e){
            List erro = new ArrayList();
            erro.add(e.toString());
            return erro;
        }
    }



    public List todosFilmesBemAvaliados() {
        try {
            URL url = new URL("https://api.themoviedb.org/3/movie/top_rated?language=pt-BR");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("accept", "application/json");
            con.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0YjFjYWYxNDNhMjA2ZmFjMWU0ZmFkNjIxZjJjY2NlZSIsIm5iZiI6MTcyNTQ1MTk3Mi42MjU4Miwic3ViIjoiNjZkODRkYjI0Yjc0MTRkNGIxMWFiNmZjIiwic2NvcGVzIjpbImFwaV9yZWFkIl0sInZlcnNpb24iOjF9._irTp0YQwrdzrXMH7DfkACI3uEQh6RfwexNgwaWSQU0");

            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line;
            StringBuilder resposta = new StringBuilder();

            while((line = bf.readLine()) != null){
                resposta.append(line);
            }

            bf.close();

            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(resposta.toString());

            List listaDeFilmes = (List) json.get("results");

            return listaDeFilmes;
        }
        catch(Exception e){
            List erro = new ArrayList();
            erro.add(e.toString());
            return erro;
        }
    }

    public List filmesNovos() {
        try {
            URL url = new URL("https://api.themoviedb.org/3/movie/upcoming?language=pt-BR");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("accept", "application/json");
            con.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0YjFjYWYxNDNhMjA2ZmFjMWU0ZmFkNjIxZjJjY2NlZSIsIm5iZiI6MTcyNTQ1MTk3Mi42MjU4Miwic3ViIjoiNjZkODRkYjI0Yjc0MTRkNGIxMWFiNmZjIiwic2NvcGVzIjpbImFwaV9yZWFkIl0sInZlcnNpb24iOjF9._irTp0YQwrdzrXMH7DfkACI3uEQh6RfwexNgwaWSQU0");

            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line;
            StringBuilder resposta = new StringBuilder();

            while((line = bf.readLine()) != null){
                resposta.append(line);
            }

            bf.close();

            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(resposta.toString());

            List listaDeFilmes = (List) json.get("results");

            return listaDeFilmes;
        }
        catch(Exception e){
            List erro = new ArrayList();
            erro.add(e.toString());
            return erro;
        }
    }

    public Object buscaFilme(int id) {
        try {
            URL url = new URL("https://api.themoviedb.org/3/movie/"+id+"?language=pt-BR");//+"?language=pt-BR");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("accept", "application/json");
            con.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0YjFjYWYxNDNhMjA2ZmFjMWU0ZmFkNjIxZjJjY2NlZSIsIm5iZiI6MTcyNTQ1MTk3Mi42MjU4Miwic3ViIjoiNjZkODRkYjI0Yjc0MTRkNGIxMWFiNmZjIiwic2NvcGVzIjpbImFwaV9yZWFkIl0sInZlcnNpb24iOjF9._irTp0YQwrdzrXMH7DfkACI3uEQh6RfwexNgwaWSQU0");

            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line;
            StringBuilder resposta = new StringBuilder();

            while((line = bf.readLine()) != null){
                resposta.append(line);
            }

            bf.close();

            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(resposta.toString());

            return json;
        }
        catch(Exception e){
            Object erro = e;
            return erro;
        }
    }

    public List pesquisaFilmes(String texto) {
        try{
            texto = texto.replace(" ", "%");

            URL url = new URL("https://api.themoviedb.org/3/search/movie?query="+texto+"&language=pt-BR");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("accept", "application/json");
            con.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0YjFjYWYxNDNhMjA2ZmFjMWU0ZmFkNjIxZjJjY2NlZSIsIm5iZiI6MTcyNTQ1MTk3Mi42MjU4Miwic3ViIjoiNjZkODRkYjI0Yjc0MTRkNGIxMWFiNmZjIiwic2NvcGVzIjpbImFwaV9yZWFkIl0sInZlcnNpb24iOjF9._irTp0YQwrdzrXMH7DfkACI3uEQh6RfwexNgwaWSQU0");

            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line;
            StringBuilder resposta = new StringBuilder();

            while ((line = bf.readLine()) != null) {
                resposta.append(line);
            }

            bf.close();

            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(resposta.toString());

            List resultados = (List) json.get("results");

            return resultados;
        }
        catch(Exception e){
            List erro = new ArrayList();
            erro.add(e.toString());
            return erro;
        }

    }

    @Autowired
    FavoritosRepository favoritosRepository;

    public List favoritos(){

        List<Favoritos> dados = new ArrayList();
        dados = favoritosRepository.findAll();

        List filmes = new ArrayList();

        if (dados != null) {

            for (Favoritos dado : dados) {
                try {
                    URL url = new URL("https://api.themoviedb.org/3/movie/" + dado.getId() + "?language=pt-BR");//+"?language=pt-BR");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");
                    con.setRequestProperty("accept", "application/json");
                    con.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0YjFjYWYxNDNhMjA2ZmFjMWU0ZmFkNjIxZjJjY2NlZSIsIm5iZiI6MTcyNTQ1MTk3Mi42MjU4Miwic3ViIjoiNjZkODRkYjI0Yjc0MTRkNGIxMWFiNmZjIiwic2NvcGVzIjpbImFwaV9yZWFkIl0sInZlcnNpb24iOjF9._irTp0YQwrdzrXMH7DfkACI3uEQh6RfwexNgwaWSQU0");

                    BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String line;
                    StringBuilder resposta = new StringBuilder();

                    while ((line = bf.readLine()) != null) {
                        resposta.append(line);
                    }

                    bf.close();

                    JSONParser parser = new JSONParser();
                    JSONObject json = (JSONObject) parser.parse(resposta.toString());

                    filmes.add(json);
                } catch (Exception e) {

                }
            }

            return filmes;

        }
        else {

            return dados;

        }
    }


    public boolean favoritoExiste(int id) {
        if (favoritosRepository.existsById(id)){
            return true;
        }
        else return false;
    }




    public void adicionarFavorito(int id) {

        var novoFavorito = new Favoritos();
        novoFavorito.setId(id);
        favoritosRepository.save(novoFavorito);

    }


    public void removerFavorito(int id) {
        Favoritos removido = favoritosRepository.encontrarFilme(id);
        favoritosRepository.delete(removido);
    }


    public int isFavorite(int id) {

        if (favoritosRepository.existsById(id)) return id;
        else return 0;

    }
}
