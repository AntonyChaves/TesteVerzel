package com.TesteTecnico.Verzel.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record FavoritosDTO(

        @NotNull
        int id

) {
}
