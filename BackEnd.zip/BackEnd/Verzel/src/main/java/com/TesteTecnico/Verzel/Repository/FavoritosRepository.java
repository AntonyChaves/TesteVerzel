package com.TesteTecnico.Verzel.Repository;

import com.TesteTecnico.Verzel.Entity.Favoritos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FavoritosRepository extends JpaRepository<Favoritos, Integer> {

    @Query("Select a from Favoritos a where a.id = ?1")
    Favoritos encontrarFilme(int id);
}
