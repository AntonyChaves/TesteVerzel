package com.TesteTecnico.Verzel.Controller;

import com.TesteTecnico.Verzel.DTO.FavoritosDTO;
import com.TesteTecnico.Verzel.Entity.Favoritos;
import com.TesteTecnico.Verzel.Service.ServiceRequest;
import jakarta.validation.Valid;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/control")
public class ControllerRequest {

    @Autowired
    ServiceRequest serviceRequest;

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/filmesPopulares")
    public ResponseEntity filmes(){
        try{
            List filmes = serviceRequest.todosFilmesPopulares();
            return ResponseEntity.status(HttpStatus.FOUND).body(filmes);
        }
        catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/filmesBemAvaliados")
    public ResponseEntity filmesBemAvaliados(){
        try{
            List filmes = serviceRequest.todosFilmesBemAvaliados();
            return ResponseEntity.status(HttpStatus.FOUND).body(filmes);
        }
        catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/filmesNovos")
    public ResponseEntity filmesNovos(){
        try{
            List filmes = serviceRequest.filmesNovos();
            return ResponseEntity.status(HttpStatus.FOUND).body(filmes);
        }
        catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/buscaFilme/{id}")
    public ResponseEntity buscaFilme(@PathVariable ("id") int id) {
        try {
            JSONObject filme =(JSONObject) serviceRequest.buscaFilme(id);
            return ResponseEntity.status(HttpStatus.FOUND).body(filme);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/pesquisa/{texto}")
    public ResponseEntity pesquisa(@PathVariable ("texto") String texto) {
        try{
            List filmes = serviceRequest.pesquisaFilmes(texto);
            return ResponseEntity.status(HttpStatus.FOUND).body(filmes);
        }
        catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }






    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/todosFavoritos")
    public ResponseEntity todosFavoritos(){
        try{
            List favoritos = serviceRequest.favoritos();
            if (favoritos.toArray().length > 0){
                return ResponseEntity.status(HttpStatus.FOUND).body(favoritos);
            }
            else{
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Você não possui filmes cadastrados na sua lista de favoritos");
            }

        }
        catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/verificaFavorito/{id}")
    public ResponseEntity isFavorite(@PathVariable ("id") int id){
        try {

            int favorito = serviceRequest.isFavorite(id);
            if (favorito == id) {
                return ResponseEntity.status(HttpStatus.FOUND).body(favorito);
            }
            else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(0);
            }
        }
        catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }


    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping("/adicionarFavorito/{id}")
    public ResponseEntity adicionarFavorito(@PathVariable ("id") int id){

        if (serviceRequest.favoritoExiste(id)){
            return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body("Essa filme já foi adicionado aos favoritos");
        }

        else {

            try {
                serviceRequest.adicionarFavorito(id);
                return ResponseEntity.status(HttpStatus.CREATED).body("Filme adicionado com sucesso aos Favoritos!");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
            }
        }
    }


    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @DeleteMapping("/removerFavorito/{id}")
    public ResponseEntity removerFavorito(@PathVariable ("id") int id){
        try{
            serviceRequest.removerFavorito(id);
            return ResponseEntity.status(HttpStatus.CREATED).body("Filme removido com sucesso dos Favoritos!");
        }
        catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e);
        }
    }






}
