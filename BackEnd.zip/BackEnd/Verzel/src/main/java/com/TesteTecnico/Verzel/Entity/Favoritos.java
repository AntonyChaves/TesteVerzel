package com.TesteTecnico.Verzel.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tmdb_favoritos_API")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Favoritos {

    @Id
    @Column
    private int id;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}

